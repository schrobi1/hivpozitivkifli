<?php
function PrintMenu()
{
        echo '<li><a href="index.php">Főoldal</a></li>
        <li><a href="index.php?page=belfold">Belföld</a></li>
        <li><a href="index.php?page=kulfold">Külföld</a></li>
        <li><a href="index.php?page=sport">Sport</a></li>
        <li><a href="index.php?page=tudomany">Tudomány</a></li>
        <li><a href="index.php?page=tech">Tech</a></li>
        <li><a href="index.php?page=politika">Politika</a></li>
        <li><a href="index.php?page=pletyka">Pletyka</a></li>';
}
?>
<footer>
    <div class="foot0">
        <h2>Elérhetőségek</h2>
        <ul>					
            <li><p>E-mail: web2@gmail.com</p></li>
            <li><p>Telefon: +36 30 123 4567</p></li>
            <li><p>Tulajdonos: Egy tanuló csapat</p></li>
            <li><p>Cím: PTE TTK F épület</p></li>
        </ul>
    </div>
    <div class="foot1">
        <h2>Oldalunkról</h2>
        <p>
            In sodales gravida arcu condimentum feugiat. Nam dignissim urna a diam faucibus euismod. Quisque dictum semper posuere. Duis aliquam orci libero, at euismod dui vulputate sed. Suspendisse sed felis nec mauris dignissim blandit sit amet in nisi. Donec faucibus libero justo, quis cursus justo dignissim nec.
        </p>
    </div>
    <div class="foot2">
        <h2>Itt is keresd az oldalt:</h2>
        <ul>						
            <li>
                <a href="https://www.facebook.com/"><img src="Ikonok\faceLogo.png"></a>
            </li>
            <li>
                <a href="https://www.instagram.com/"><img src="Ikonok\instaLogo.png"></a>
                <a href="https://twitter.com/"><img src="Ikonok\twitterLogo.png"></a>
            </li>
        </ul>
    </div>
</footer>
</body>
</html>
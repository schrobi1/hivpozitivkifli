<?php
include "inc/functions.php";
include "inc/begin.php";
include "inc/maiside.php";
include "inc/end.php";
?>		
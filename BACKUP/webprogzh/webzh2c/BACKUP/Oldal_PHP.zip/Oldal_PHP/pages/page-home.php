<main>
    <h2>Lorem ipsum dolor</h2>
    <p>
        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc pretium semper convallis. Quisque vestibulum dui sit amet mattis blandit. Proin ornare, elit nec tincidunt maximus, libero nibh egestas mi, et facilisis neque neque a enim.
    </p>
    <div class="pics">
        <img src="main0.jpg">
        <img src="main1.jpg">
    </div>
        <div class="CikkLink">
            <a href="index.html">Részletek</a>
        </div>
    <div class="csik"></div>
</main>